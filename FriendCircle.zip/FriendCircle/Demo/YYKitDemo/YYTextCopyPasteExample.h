//
//  YYTextCopyPasteExample.h
//  YYKitExample
//
//  Created by ibireme on 15/9/12.
//  Copyright (c) 2015 ibireme. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYTextCopyPasteExample : UIViewController

@end

//
//  YYTextRubyExample.h
//  YYKitExample
//
//  Created by ibireme on 15/9/9.
//  Copyright (C) 2015 ibireme. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYTextRubyExample : UIViewController

@end

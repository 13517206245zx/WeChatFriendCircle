//
//  WeChatCell.m
//  ZXWeChat
//
//  Created by Mrs_zhang on 16/10/24.
//  Copyright © 2016年 Mrs_zhang. All rights reserved.
//

#import "WeChatCell.h"
#import "YYControl.h"

@implementation WeChatCell{
    BOOL _avatarTouch;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        @weakify(self);

        _avatarView = [UIImageView new];
        _avatarView.frame = CGRectMake(10, 10, 40, 40);
        _avatarView.backgroundColor = lightColor;
        _avatarView.contentMode = UIViewContentModeScaleAspectFill;
        [self.contentView addSubview:_avatarView];
        
        _nameLabel = [YYLabel new];
        _nameLabel.frame = CGRectMake(CGRectGetMaxX(_avatarView.frame)+5, 10, 200, 23);
        _nameLabel.lineBreakMode = NSLineBreakByClipping;
        _nameLabel.textVerticalAlignment = YYTextVerticalAlignmentCenter;
        [self.contentView addSubview:_nameLabel];
        
        _timeLabel = [YYLabel new];
        _timeLabel.font = [UIFont systemFontOfSize:13.f];
        _timeLabel.textColor = [UIColor lightGrayColor];
        _timeLabel.textVerticalAlignment = YYTextVerticalAlignmentCenter;
        _timeLabel.frame = CGRectMake(CGRectGetMaxX(_avatarView.frame)+5, 35, 200, 15);
        [self.contentView addSubview:_timeLabel];

        _contextLabel = [YYLabel new];
        _contextLabel.frame = CGRectZero;
        _contextLabel.font = [UIFont systemFontOfSize:15.f];
        _contextLabel.textVerticalAlignment = YYTextVerticalAlignmentTop;
        _contextLabel.displaysAsynchronously = YES;
        _contextLabel.ignoreCommonProperties = YES;
        _contextLabel.fadeOnAsynchronouslyDisplay = NO;
        _contextLabel.fadeOnHighlight = NO;

        [self.contentView addSubview:_contextLabel];
        
        NSMutableArray *picViews = [NSMutableArray new];
        CGFloat imageWidth = (kScreenWidth - 50.0f)/3.0f;

        for (int i = 0; i < kPicCount; i++) {
            YYControl *imageView = [YYControl new];
            imageView.size = CGSizeMake(imageWidth, imageWidth);
            imageView.hidden = YES;
            imageView.clipsToBounds = YES;
            imageView.backgroundColor = lightColor;
            imageView.exclusiveTouch = YES;
            imageView.touchBlock = ^(YYControl *view, YYGestureRecognizerState state, NSSet *touches, UIEvent *event) {
                
                if (![weak_self.delegate respondsToSelector:@selector(cell:didClickImageAtIndex:)]) return;
                if (state == YYGestureRecognizerStateEnded) {
                    UITouch *touch = touches.anyObject;
                    CGPoint p = [touch locationInView:view];
                    if (CGRectContainsPoint(view.bounds, p)) {
                        [weak_self.delegate cell:weak_self didClickImageAtIndex:i];
                    }
                }

            };
            
            [picViews addObject:imageView];
            [self.contentView addSubview:imageView];
        }
        _picViews = picViews;
        
        _videoView = [UIImageView new];
        _videoView.hidden = YES;
        _videoView.backgroundColor = lightColor;
        _videoView.userInteractionEnabled = YES;
        [self.contentView addSubview:_videoView];
        
        _videoPlayBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _videoPlayBtn.hidden = YES;
        [_videoPlayBtn setImage:[UIImage imageNamed:@"yr_show_video"] forState:UIControlStateNormal];
        [_videoPlayBtn addTarget:self action:@selector(didClickPlayVideoButton:) forControlEvents:UIControlEventTouchUpInside];
        [_videoView addSubview:_videoPlayBtn];
        
        _commentView = [UIView new];
        [self.contentView addSubview:_commentView];
        
        _lineOne = [CALayer layer];
        _lineOne.backgroundColor = lightColor.CGColor;
        [_commentView.layer addSublayer:_lineOne];
        
        _lineTwo = [CALayer layer];
        _lineTwo.backgroundColor = lightColor.CGColor;
        [_commentView.layer addSublayer:_lineTwo];
        
        _likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_likeBtn setTitle:@"赞" forState:UIControlStateNormal];
        [_likeBtn setTitleColor:[UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000] forState:UIControlStateNormal];
        [_likeBtn setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
        [_likeBtn setImage:[UIImage imageNamed:@"yr_show_bluelike"] forState:UIControlStateNormal];
        [_likeBtn setImage:[UIImage imageNamed:@"yr_sunText_like"] forState:UIControlStateSelected];
        [_commentView addSubview:_likeBtn];
        
        _commentBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_commentBtn setTitle:@"评论" forState:UIControlStateNormal];
        [_commentBtn setTitleColor:[UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000] forState:UIControlStateNormal];
        [_commentBtn setImage:[UIImage imageNamed:@"yr_show_bluecomment"] forState:UIControlStateNormal];
        [_commentView addSubview:_commentBtn];
        
        
        [_likeBtn addTarget:self action:@selector(didclickedLikeButton:) forControlEvents:UIControlEventTouchUpInside];
        [_commentBtn addTarget:self action:@selector(didClickedCommentButton:) forControlEvents:UIControlEventTouchUpInside];

        
        _bgView = [UIView new];
        _bgView.hidden = YES;
        _bgView.backgroundColor = lightColor;
        [self.contentView addSubview:_bgView];

        _likeLabel = [YYLabel new];
        _likeLabel.textColor = [UIColor blackColor];
        _likeLabel.textAlignment = NSTextAlignmentCenter;
        _likeLabel.textVerticalAlignment = YYTextVerticalAlignmentCenter;
        _likeLabel.numberOfLines = 0;
        [self.contentView addSubview:_likeLabel];
        
        _likeImage = [UIImageView new];
        _likeImage.hidden = YES;
        _likeImage.image = [UIImage imageNamed:@"yr_show_like"];
        _likeImage.contentMode = UIViewContentModeScaleAspectFill;
        [self.contentView addSubview:_likeImage];
 
        NSMutableArray *commentViews = [NSMutableArray new];

        for (int i = 0; i  < kCommentCount; i++) {
            YYLabel *commentLab = [YYLabel new];
            commentLab.size = CGSizeMake(0, 0);
            commentLab.textColor = [UIColor blackColor];
            commentLab.textVerticalAlignment = NSTextAlignmentCenter;
            commentLab.numberOfLines = 0;
            commentLab.hidden = YES;
            [commentViews addObject:commentLab];
            
            
            [self.contentView addSubview:commentLab];

        }
        _commentViews = commentViews;
        
        _commentImage = [UIImageView new];
        _commentImage.hidden = YES;
        _commentImage.image = [UIImage imageNamed:@"yr_show_comment"];
        _commentImage.contentMode = UIViewContentModeScaleAspectFill;
        [self.contentView addSubview:_commentImage];
        
        _moreCommentBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _moreCommentBtn.backgroundColor = [UIColor colorWithRed:(237)/255.0f green:(237)/255.0f blue:(237)/255.0f alpha:1.0];
        _moreCommentBtn.hidden = YES;
        _moreCommentBtn.layer.cornerRadius = 2.0f;
        [_moreCommentBtn setTitle:@"查看更多评论" forState:UIControlStateNormal];
        [_moreCommentBtn setTitleColor:[UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000] forState:UIControlStateNormal];
        _moreCommentBtn.titleLabel.font = [UIFont systemFontOfSize:15.f];
        [_moreCommentBtn addTarget:self action:@selector(moreCommentAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_moreCommentBtn];
    
    }
    return self;
}

- (void)setLayout:(WeChatModel *)layout{
    
    [_avatarView setImageWithURL:[NSURL URLWithString:layout.avatar] placeholder:nil];
    
    _nameLabel.text = layout.custName;
    _timeLabel.text = layout.time;
    
    _contextLabel.frame = CGRectMake(10, 60, kScreenWidth-20, layout.textHeight-10);
    _contextLabel.textLayout = layout.textLayout;
    
    [self _setImageViewWithPics:layout];
    
    [self _setLikeAndCommentViewHeight:layout];
    
    [self _setLikeViewWithHeight:layout];
    
    [self _setCommentViewWithHeight:layout];
    
    [self _setMoreCommentBtnWithHeight:layout];
    
    [self _setBgViewWithHeight:layout];
    
}

//图片布局
- (void)_setImageViewWithPics:(WeChatModel *)layout {

        CGFloat imageWidth = (kScreenWidth - 30.0f)/3.0f;
        CGSize picSize;
        NSArray *pics =  layout.pics;
        int picsCount = (int)pics.count;
        
        for (int i = 0; i < kPicCount; i++) {
            UIView *imageView = _picViews[i];
            if (i >= picsCount) {
                [imageView.layer cancelCurrentImageRequest];
                imageView.hidden = YES;
            } else {
                
                CGPoint origin = {0};
                switch (picsCount) {
                    case 1: {
                        origin.x = 10;
                        origin.y = layout.textHeight +60;
                        picSize = CGSizeMake(imageWidth*1.7, imageWidth*1.7);
                        
                    } break;
                    case 4: {
                        origin.x = 10 + (i % 2) * (picSize.width + 5);
                        origin.y = layout.textHeight +60 + (int)(i / 2) * (picSize.height + 5);
                        picSize = CGSizeMake(imageWidth, imageWidth);
                        
                    } break;
                    default: {
                        
                        origin.x = 10 + (i % 3) * (picSize.width + 5);
                        origin.y = layout.textHeight +60 + (int)(i / 3) * (picSize.height + 5);
                        picSize = CGSizeMake(imageWidth, imageWidth);
                        
                    } break;
                }
                imageView.frame = (CGRect){.origin = origin, .size = picSize};
                imageView.hidden = NO;
                imageView.contentMode = UIViewContentModeScaleAspectFill;
                
                [imageView.layer removeAnimationForKey:@"contents"];
                
                
                @weakify(imageView);
                [imageView.layer setImageWithURL:pics[i]
                                     placeholder:nil
                                         options:YYWebImageOptionAvoidSetImage
                                      completion:^(UIImage *image, NSURL *url, YYWebImageFromType from, YYWebImageStage stage, NSError *error) {
                                          @strongify(imageView);
                                          ((YYControl *)imageView).image = image;
                                          imageView.contentMode = UIViewContentModeScaleAspectFill;
                                          if (from != YYWebImageFromMemoryCacheFast) {
                                              CATransition *transition = [CATransition animation];
                                              transition.duration = 0.15;
                                              transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
                                              transition.type = kCATransitionFade;
                                              [imageView.layer addAnimation:transition forKey:@"contents"];
                                          }
                                          
                                      }];
            }
        }
    if ([layout.type isEqualToString:@"image"]) {
        _videoView.frame = CGRectMake(10, layout.textHeight +60, 0, 0);
        _videoPlayBtn.frame = CGRectMake((kScreenWidth- 100)/2, 5.0f+65.f, 0, 0);

    }else{
        _videoView.hidden = NO;
        _videoPlayBtn.hidden = NO;
        _videoView.frame = CGRectMake(10, layout.textHeight +60, kScreenWidth-20, 200);
        _videoPlayBtn.frame = CGRectMake((kScreenWidth- 100)/2, 5.0f+65.f, 100, 70);

    }
    
}

//点赞、礼物、评论按钮
- (void)_setLikeAndCommentViewHeight:(WeChatModel *)layout{
    
    CGFloat h;
    if ([layout.type isEqualToString:@"image"]) {
        h = layout.picHeight;
    }else{
        h = 210;
    }
    
    _commentView.frame = CGRectMake(kScreenWidth-140, h + layout.textHeight + kProfileViewHeight+10, 130, 30);
    _commentView.layer.cornerRadius = 4.f;
    _commentView.layer.borderColor = lightColor.CGColor;
    _commentView.layer.borderWidth = .5f;
    _commentView.clipsToBounds = YES;
    
    _lineOne.frame = CGRectMake(_commentView.frame.size.width/2, 0, 0.5, 30);
    
    _likeBtn.frame = CGRectMake(2, 0, 60, 30);
    _commentBtn.frame = CGRectMake(67, 0, 60, 30);
    
}
//点赞列表布局
- (void)_setLikeViewWithHeight:(WeChatModel *)layout{
    int rangeOffset = 0;
    
    NSMutableAttributedString *one = [[NSMutableAttributedString alloc] init];
    NSArray *likeArr = layout.likes;
    for (NSInteger i = 0;i < likeArr.count; i ++) {
        NSString *like = likeArr[i];
        NSInteger length = like.length;
        if (likeArr.count >1) {
            if (i!= likeArr.count-1) {
                like = [NSString stringWithFormat:@"%@、",like];
                length = like.length-1;
            }
        }
        one.font = [UIFont systemFontOfSize:kContentFont];
        [one appendString:like];
        
        NSRange range = NSMakeRange(rangeOffset, length);
        [one setTextHighlightRange:range
                             color:[UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000]
                   backgroundColor:[UIColor colorWithWhite:0.000 alpha:0.220]
                         tapAction:^(UIView *containerView, NSAttributedString *text, NSRange range, CGRect rect) {
                             
                             @weakify(self);
                             
                             if ([weak_self.delegate respondsToSelector:@selector(cellDidClickLikeAndComment:Name:)]) {
                                 [weak_self.delegate cellDidClickLikeAndComment:weak_self Name:[text.string substringWithRange:range]];
                             }

                         }];
        rangeOffset += like.length;
    }

    if (layout.likes.count >0) {
        _likeLabel.attributedText = one;
        _likeLabel.font = [UIFont systemFontOfSize:kContentFont];
        _likeLabel.frame = CGRectMake(40, CGRectGetMaxY(_commentView.frame) +10, kScreenWidth - kCommentsPadding, 30);
        _likeImage.hidden = NO;
        _likeImage.frame = CGRectMake(20,_likeLabel.frame.origin.y +9, 15, 15);
        }else{
        _likeLabel.frame = CGRectMake(40, CGRectGetMaxY(_commentView.frame) +10, 0, 0);
        _likeImage.frame = CGRectMake(20,_likeLabel.frame.origin.y +9, 0, 0);
    }
}
//评论列表布局
- (void)_setCommentViewWithHeight:(WeChatModel *)layout{
    
        [_commentViews enumerateObjectsUsingBlock:^(YYLabel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            obj.frame = CGRectZero;
            obj.hidden = YES;
        }];
    
        NSArray *commentArray;
        if (layout.comments.count>kCommentCount) {
           commentArray  = [layout.comments subarrayWithRange:NSMakeRange(0, kCommentCount)];
        }else{
           commentArray = layout.comments;
        }
    
        for (NSInteger i = 0;i < commentArray.count; i ++) {
            
            YYLabel *commentLab = _commentViews[i];
            
            NSDictionary *dic = commentArray[i];
            NSString *from = dic[@"from"];
            NSString *to = dic[@"to"];
            NSString *content = dic[@"content"];
            
            int rangeOffset = 0;
            
            NSMutableAttributedString *one = [[NSMutableAttributedString alloc] init];
            
            
            if (to && ![to isEqualToString:@""]) {
                
                NSRange range = NSMakeRange(rangeOffset, from.length);
                NSRange range1 = NSMakeRange(rangeOffset+from.length + 2, to.length);
                
                [one appendString:[NSString stringWithFormat:@"%@回复%@: %@",from,to,content]];
                one.font = [UIFont systemFontOfSize:kContentFont];
                
                
                [one setTextHighlightRange:range
                                     color:[UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000]
                           backgroundColor:[UIColor colorWithWhite:0.000 alpha:0.220]
                                 tapAction:^(UIView *containerView, NSAttributedString *text, NSRange range, CGRect rect) {
                                     
                                     @weakify(self);
                                     
                                     if ([weak_self.delegate respondsToSelector:@selector(cellDidClickLikeAndComment:Name:)]) {
                                         [weak_self.delegate cellDidClickLikeAndComment:weak_self Name:[text.string substringWithRange:range]];
                                     }
                                     
                                 }];
                
                [one setTextHighlightRange:range1
                                     color:[UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000]
                           backgroundColor:[UIColor colorWithWhite:0.000 alpha:0.220]
                                 tapAction:^(UIView *containerView, NSAttributedString *text, NSRange range, CGRect rect) {
                                     
                                     @weakify(self);
                                     
                                     if ([weak_self.delegate respondsToSelector:@selector(cellDidClickLikeAndComment:Name:)]) {
                                         [weak_self.delegate cellDidClickLikeAndComment:weak_self Name:[text.string substringWithRange:range]];
                                     }
                                     
                                 }];
                
            }else{
                NSRange range = NSMakeRange(rangeOffset, from.length);
                
                [one appendString:[NSString stringWithFormat:@"%@: %@",from,content]];
                one.font = [UIFont systemFontOfSize:kContentFont];
                
                
                [one setTextHighlightRange:range
                                     color:[UIColor colorWithRed:0.093 green:0.492 blue:1.000 alpha:1.000]
                           backgroundColor:[UIColor colorWithWhite:0.000 alpha:0.220]
                                 tapAction:^(UIView *containerView, NSAttributedString *text, NSRange range, CGRect rect) {
                                     
                                     @weakify(self);
                                     
                                     if ([weak_self.delegate respondsToSelector:@selector(cellDidClickLikeAndComment:Name:)]) {
                                         [weak_self.delegate cellDidClickLikeAndComment:weak_self Name:[text.string substringWithRange:range]];
                                     }
                                     
                                 }];
                
            }
            
            NSDictionary *comDic = layout.commentHs[i];
            CGFloat commentH = [comDic[@"commentH"] floatValue];
            CGFloat commentY = [comDic[@"commentY"] floatValue];
            
            
            if (layout.comments) {

                commentLab.hidden = NO;
                commentLab.attributedText = one;
                commentLab.frame = CGRectMake(40, CGRectGetMaxY(_likeLabel.frame)+commentY, kScreenWidth-kCommentsPadding, commentH);

            }else{
                commentLab.frame = CGRectMake(40, CGRectGetMaxY(_likeLabel.frame)+i*25 , 0, 0);
            }
        }
    
    
    if (layout.comments.count>0) {
        _commentImage.hidden = NO;
        _commentImage.frame = CGRectMake(20, CGRectGetMaxY(_likeLabel.frame)+4, 13, 13);
    }else{
        _commentImage.frame = CGRectMake(20, CGRectGetMaxY(_likeLabel.frame), 0, 0);
    }
    
}

//查看更多按钮
- (void)_setMoreCommentBtnWithHeight:(WeChatModel *)layout{
    
    CGFloat likesH;
    CGFloat commentH;
    if (layout.likes.count >0) {
        likesH = layout.likeViewHeight - 10;
        commentH = layout.commentViewHeight;
    }else{
        likesH = layout.likeViewHeight;
        commentH = layout.commentViewHeight - 10;
    }
    
    if (layout.comments.count >= 5) {
        _moreCommentBtn.hidden = NO;
        _moreCommentBtn.frame = CGRectMake((kScreenWidth-30-100)/2+10,_likeLabel.frame.origin.y +likesH +commentH , 100,23.f);
    }else{
        _moreCommentBtn.hidden = YES;
       _moreCommentBtn.frame = CGRectMake((kScreenWidth-30-100)/2+10,_likeLabel.frame.origin.y +likesH +commentH , 0,0);
    }
}

//背景图片布局
- (void)_setBgViewWithHeight:(WeChatModel *)layout{

      CGFloat likesH;
      CGFloat commentH;
      if (layout.likes.count >0) {
          likesH = layout.likeViewHeight - 10;
          commentH = layout.commentViewHeight;
      }else{
          likesH = layout.likeViewHeight;
          commentH = layout.commentViewHeight - 10;
      }
    

        if (layout.likes.count == 0 && layout.comments.count == 0) {
            _bgView.frame = CGRectMake(10, _likeLabel.frame.origin.y, kScreenWidth-20, 0);

        }else{
            
            if (layout.comments.count >= 5) {
                _bgView.frame = CGRectMake(10, _likeLabel.frame.origin.y, kScreenWidth-20, likesH + commentH +30);
                _bgView.hidden = NO;
            }else{
                _bgView.frame = CGRectMake(10, _likeLabel.frame.origin.y, kScreenWidth-20, likesH + commentH);
                _bgView.hidden = NO;
            }
        }
    
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    _avatarTouch = NO;
    UITouch *t = touches.anyObject;
    CGPoint p = [t locationInView:_avatarView];
    if (CGRectContainsPoint(_avatarView.bounds, p)) {
        _avatarTouch = YES;
    }
    p = [t locationInView:_nameLabel];
    if (CGRectContainsPoint(_nameLabel.bounds, p) && _nameLabel.textLayout.textBoundingRect.size.width > p.x) {
        _avatarTouch = YES;
    }
    if (!_avatarTouch) {
        [super touchesBegan:touches withEvent:event];
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    @weakify(self);
    if (!_avatarTouch) {
        [super touchesEnded:touches withEvent:event];
    } else {
        if ([weak_self.delegate respondsToSelector:@selector(cellDidClickUser:)]) {
            [weak_self.delegate cellDidClickUser:weak_self];
        }
    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event {
    if (!_avatarTouch) {
        [super touchesCancelled:touches withEvent:event];
    }
}

//点赞
- (void)didclickedLikeButton:(UIButton *)sender{
    @weakify(self);
    
    if ([weak_self.delegate respondsToSelector:@selector(cellDidClickLike:)]) {
        [weak_self.delegate cellDidClickLike:weak_self];
    }
}
//评论
- (void)didClickedCommentButton:(UIButton *)sender{
    @weakify(self);

    if ([weak_self.delegate respondsToSelector:@selector(cellDidClickComment:)]) {
        [weak_self.delegate cellDidClickComment:weak_self];
    }
}

//查看更多
- (void)moreCommentAction:(UIButton *)sender{
    @weakify(self);
    
    if ([weak_self.delegate respondsToSelector:@selector(cellDidClickMoreComment:)]) {
        [weak_self.delegate cellDidClickMoreComment:weak_self];
    }
}

//视频播放
- (void)didClickPlayVideoButton:(UIButton *)sender{
    @weakify(self);
    
    if ([weak_self.delegate respondsToSelector:@selector(cellDidClickPlayVideo:)]) {
        [weak_self.delegate cellDidClickPlayVideo:weak_self];
    }
}



@end

//
//  WeChatCell.h
//  ZXWeChat
//
//  Created by Mrs_zhang on 16/10/24.
//  Copyright © 2016年 Mrs_zhang. All rights reserved.
//

#import "YYTableViewCell.h"
#import "WeChatModel.h"

#import "YYKit.h"

#define lightColor [UIColor colorWithRed:(245)/255.0f green:(245)/255.0f blue:(245)/255.0f alpha:1.0]

@class WeChatCell;
@protocol WechatCellDelegate <NSObject>

/// 点击了图片
- (void)cell:(WeChatCell *)cell didClickImageAtIndex:(NSUInteger)index;
/// 点击了评论
- (void)cellDidClickComment:(WeChatCell *)cell;
/// 点击了赞
- (void)cellDidClickLike:(WeChatCell *)cell;
/// 点击了用户
- (void)cellDidClickUser:(WeChatCell *)cell;

/// 查看更多
- (void)cellDidClickMoreComment:(WeChatCell *)cell;
///点赞评论用户名
- (void)cellDidClickLikeAndComment:(WeChatCell *)cell Name:(NSString *)name;
/// 视频播放
- (void)cellDidClickPlayVideo:(WeChatCell *)cell;
@end


@interface WeChatCell : YYTableViewCell

@property (nonatomic, strong) UIImageView *avatarView; ///< 头像

@property (nonatomic, strong) YYLabel *nameLabel;

@property (nonatomic, strong) YYLabel *timeLabel;

@property (nonatomic, strong) YYLabel *contextLabel;     // 文本

@property (nonatomic, strong) NSArray<UIView *> *picViews;      // 图片

@property (nonatomic,strong) UIImageView *videoView; //小视频

@property (nonatomic,strong) UIButton *videoPlayBtn;

@property (nonatomic,strong) UIView  *commentView;
@property (nonatomic,strong) CALayer *lineOne;
@property (nonatomic,strong) CALayer *lineTwo;

@property (nonatomic,strong) UIButton *likeBtn;
@property (nonatomic,strong) UIButton *giftBtn;
@property (nonatomic,strong) UIButton *commentBtn;

@property (nonatomic,strong) YYLabel *likeLabel;     // 点赞文本
@property (nonatomic,strong) UIImageView *likeImage;

@property (nonatomic, strong) UILabel *lab;

@property (nonatomic, strong) NSArray<YYLabel *> *commentViews;      // 评论
@property (nonatomic,strong) UIImageView *commentImage;


@property (nonatomic, strong) UIButton *moreCommentBtn; //查看更多

@property (nonatomic, strong) UIView *bgView;

@property (nonatomic, weak) id<WechatCellDelegate> delegate;

@property (nonatomic,strong) WeChatModel *layout;



@end

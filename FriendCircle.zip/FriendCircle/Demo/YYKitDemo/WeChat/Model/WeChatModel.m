//
//  WeChatModel.m
//  YYKitDemo
//
//  Created by Mrs_zhang on 16/10/25.
//  Copyright © 2016年 ibireme. All rights reserved.
//

#import "WeChatModel.h"

@interface WeChatModel()

@end

@implementation WeChatModel
@synthesize videoPic = _videoPic;

- (void)setVideoPic:(NSString *)videoPic{
    
    _videoPic = videoPic;
}


- (NSString *)type{
    NSString *type_;
    
    if (_videoPic == nil || [_videoPic isEqualToString:@""]) {
        type_ = @"image";
    }else{
        type_ = @"video";
    }
    
    return type_;
}

- (CGFloat)height{
    
    _profileHeight = kProfileViewHeight;
    CGFloat commentAndLikeViewHeight = 40;
    
    [self _layoutText];
    [self _layoutPics];
    [self _layoutLikes];
    [self _layoutComments];
    
    // 计算高度
    _height = 0;
    _height += _profileHeight;
    _height += commentAndLikeViewHeight;
    _height += _likeViewHeight;
    _height += _commentViewHeight;
    if (_textHeight > 0) {
        _height += _textHeight;
    }
    if (_picHeight > 0) {
        _height += _picHeight;
    }
    if (_comments.count >=5) {
        _height += 30;
    }
    
    _height += 10;

    return _height;
}

- (void)_layoutText{
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 3; // 调整行间距

    NSMutableAttributedString *stringText = [[NSMutableAttributedString alloc] initWithString:_text];
    stringText.paragraphStyle = paragraphStyle;
    stringText.font = [UIFont systemFontOfSize:kContentFont];
    stringText.color = [UIColor blackColor];
    YYTextContainer *textContainer = [YYTextContainer containerWithSize:CGSizeMake((kScreenWidth -20) + 2 * 4, CGFLOAT_MAX)];
    textContainer.insets = UIEdgeInsetsMake(0, 4, 0, 4);
    _textLayout = [YYTextLayout layoutWithContainer:textContainer text:stringText];
    
    if (!_textLayout) return;
    
    _textHeight =  _textLayout ? (CGRectGetMaxY(_textLayout.textBoundingRect)) + 10: 0;
    
}

- (void)_layoutPics{
    NSString *type_;
    
    if (_videoPic == nil || [_videoPic isEqualToString:@""]) {
        type_ = @"image";
    }else{
        type_ = @"video";
    }
    
    if ([type_ isEqualToString:@"image"]) {
        
        if (_pics.count == 0) return;
        CGFloat picHeight = 0;
        CGFloat len1_3 = (kScreenWidth - 30.0f)/3.0f;;
        
        if (self.pics.count == 0) {
            picHeight = 0;
        }else if (self.pics.count == 1){
            picHeight = len1_3*1.7;
        }else if (self.pics.count < 4){
            picHeight = len1_3;
        }else if (self.pics.count < 7){
            picHeight = len1_3*2 + kPicPadding;
        }else{
            picHeight = len1_3*3 + 2*kPicPadding;
        }
        
        _picHeight = picHeight + 10;

    }else{
        
        _picHeight = 200 + 10;
    }
}

- (void)_layoutLikes{
    
    if (_likes.count >0) {
        _likeViewHeight = 30 +10;
    }else{
        _likeViewHeight = 0;
    }
}

- (void)_layoutComments{

    if (self.comments.count == 0 || self.comments == nil) return;
    
    CGFloat commentH = 0.f;
    
    NSArray *commentArray;
    if (self.comments.count > kCommentCount) {
      commentArray  = [self.comments subarrayWithRange:NSMakeRange(0, kCommentCount)];
    }else{
      commentArray = self.comments;
    }
    
    NSMutableArray *commentArr = [NSMutableArray array];
    for (int i = 0; i < commentArray.count; i++) {
        NSDictionary *dic = commentArray[i];
        
        NSString *from = dic[@"from"];
        NSString *to = dic[@"to"];
        NSString *content = dic[@"content"];
        NSString *commentString = @"";
        if (to && ![to isEqualToString:@""]) {
            commentString = [NSString stringWithFormat:@"%@回复%@: %@",from,to,content];
        }else{
            commentString = [NSString stringWithFormat:@"%@: %@",from,content];
        }
        
        
        NSMutableAttributedString *stringText = [[NSMutableAttributedString alloc] initWithString:commentString];
        stringText.font = [UIFont systemFontOfSize:kContentFont];
        YYTextContainer *textContainer = [YYTextContainer containerWithSize:CGSizeMake((kScreenWidth - kCommentsPadding) , CGFLOAT_MAX)];
        YYTextLayout *commentLayout = [YYTextLayout layoutWithContainer:textContainer text:stringText];
        
        if (!commentLayout) return;
        
        
        CGFloat height =  commentLayout ? (CGRectGetMaxY(commentLayout.textBoundingRect))+4: 0;
        
        NSDictionary *comDic = @{ @"commentH":@(height),
                               @"commentY":@(commentH)};
        
        [commentArr addObject:comDic];
        
        commentH += height;

    }
    
    if (_likes.count >0) {
        _commentViewHeight = commentH;
    }else{
        _commentViewHeight = commentH + 10;
    }
    _commentHs = commentArr;

}


@end

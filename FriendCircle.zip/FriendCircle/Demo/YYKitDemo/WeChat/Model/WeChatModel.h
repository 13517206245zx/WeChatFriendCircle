//
//  WeChatModel.h
//  YYKitDemo
//
//  Created by Mrs_zhang on 16/10/25.
//  Copyright © 2016年 ibireme. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YYKit.h"

#define kPicPadding 5.f
#define kCommentsPadding 50.f
#define kProfileViewHeight 50.f
#define kCommentCount 5 //此评论个数不能轻易改变
#define kPicCount 9 //此评论个数不能轻易改变
#define kContentFont 16.f


@interface WeChatModel : NSObject

// 总高度
@property (nonatomic,assign) CGFloat height;

@property (nonatomic,copy) NSString *avatar;

@property (nonatomic,copy) NSString *name;

@property (nonatomic,copy) NSString *custName;

@property (nonatomic,copy) NSString *time;

@property (nonatomic,copy) NSString *text;

@property (nonatomic,strong) NSArray *pics;

@property (nonatomic,strong) NSArray *likes;

@property (nonatomic,strong) NSArray *comments;

@property (nonatomic,assign) NSInteger isLike;

@property (nonatomic, copy) NSString* type;

@property (nonatomic, copy) NSString* custId;

@property (nonatomic, copy) NSString *sid;

@property (nonatomic, copy) NSString *videoPic;

@property (nonatomic, copy) NSString *videoUrl;

@property (nonatomic, assign) CGFloat profileHeight; //个人资料高度(包括留白)
@property (nonatomic, strong) YYTextLayout *nameTextLayout; // 名字
@property (nonatomic, strong) YYTextLayout *sourceTextLayout; //时间/来源

// 文本
@property (nonatomic, assign) CGFloat textHeight; //文本高度(包括下方留白)
@property (nonatomic, strong) YYTextLayout *textLayout; //文本

// 图片
@property (nonatomic, assign) CGFloat picHeight; //图片高度，0为没图片
@property (nonatomic, assign) CGSize picSize;

//点赞
@property (nonatomic, assign) CGFloat likeViewHeight;//点赞文字高度

//评论
@property (nonatomic, assign) CGFloat commentViewHeight;//评论总高度

@property (nonatomic, strong) NSMutableArray *commentHs;//评论高度数组


@end

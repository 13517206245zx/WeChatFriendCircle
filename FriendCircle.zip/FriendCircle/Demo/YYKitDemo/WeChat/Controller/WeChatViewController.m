//
//  ViewController.m
//  ZXWeChat
//
//  Created by Mrs_zhang on 16/10/24.
//  Copyright © 2016年 Mrs_zhang. All rights reserved.
//

#import "WeChatViewController.h"
#import "YYTableView.h"
#import "WeChatCell.h"
#import "WeChatModel.h"
#import "YYPhotoGroupView.h"
#import "YRReportTextView.h"
#import "ZXLayoutTextView.h"

#import "YYKit.h"

#define maxCommentIndex 99999999999

#define RGB_COLOR(r, g, b)       [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1.0]
#define SCREEN_WIDTH    ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT   ([UIScreen mainScreen].bounds.size.height)

@interface WeChatViewController ()<UITableViewDelegate,UITableViewDataSource,WechatCellDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *layouts;
@property (nonatomic,assign) NSInteger          commentIndex;
@property (nonatomic,strong) NSIndexPath        *commentIndexPath;

@property (nonatomic,strong) ZXLayoutTextView   *commentView;

@end

@implementation WeChatViewController

- (instancetype)init {
    self = [super init];
    
    _tableView = [YYTableView new];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _layouts = [NSMutableArray new];
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _tableView.frame = self.view.bounds;
    _tableView.scrollIndicatorInsets = _tableView.contentInset;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    _tableView.separatorColor = RGB_COLOR(237, 237, 237);
    
    [self.view addSubview:_tableView];
    
    @weakify(self);
    _commentView = [[ZXLayoutTextView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 60.0f)];
    [_commentView setSendBlock:^(YRReportTextView *textView) {
        @strongify(self);
        
        [self postCommentWithCommentText:textView.text];
        self.commentView.textView.text = @"";
        
    }];
    
    [self.view addSubview:_commentView];
    
    [_tableView registerClass:[WeChatCell class] forCellReuseIdentifier:@"cell"];
    
    [self reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return _layouts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    WeChatCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.delegate = self;
    [cell setLayout:_layouts[indexPath.row]];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return ((WeChatModel *)_layouts[indexPath.row]).height;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath {
    return NO;
}

#pragma mark - WeChatDelegate
//点击查看大图
- (void)cell:(WeChatCell *)cell didClickImageAtIndex:(NSUInteger)index{
    
    UIView *fromView = nil;
    NSMutableArray *items = [NSMutableArray new];
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];

    WeChatModel *model = _layouts[indexPath.row];
    
    NSArray *commentArray;
    if (model.pics.count>kPicCount) {
        commentArray  = [model.pics subarrayWithRange:NSMakeRange(0, kPicCount)];
    }else{
        commentArray = model.pics;
    }
    
    for (NSUInteger i = 0, max = commentArray.count; i < max; i++) {
        UIView *imgView = cell.picViews[i];
        CGFloat imageWidth = (kScreenWidth - 30.0f)/3.0f;

        YYPhotoGroupItem *item = [YYPhotoGroupItem new];
        item.thumbView = imgView;
        item.largeImageURL = [NSURL URLWithString:commentArray[i]];
        item.largeImageSize = CGSizeMake(imageWidth, imageWidth);
        [items addObject:item];
        if (i == index) {
            fromView = imgView;
        }
    }
    
    YYPhotoGroupView *v = [[YYPhotoGroupView alloc] initWithGroupItems:items];
    [v presentFromImageView:fromView toContainer:self.view animated:YES completion:nil];
}
//点赞
- (void)cellDidClickLike:(WeChatCell *)cell{

    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    WeChatModel *model = _layouts[indexPath.row];
    
    if (model.isLike == 0) {
        
        NSMutableArray* newLikeList = [[NSMutableArray alloc] initWithArray:model.likes];
        [newLikeList insertObject:@"Nike" atIndex:0];
        model.likes = newLikeList;
        model.isLike = 1;

        [_layouts replaceObjectAtIndex:indexPath.row withObject:model];

    }else{
        
        NSMutableArray* newLikeList = [[NSMutableArray alloc] initWithArray:model.likes];
        [newLikeList removeObjectAtIndex:0];
        model.likes = newLikeList;
        model.isLike = 0;

        [_layouts replaceObjectAtIndex:indexPath.row withObject:model];
    }
    [UIView animateWithDuration:0.0f animations:^{
        [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
    }];

}
//评论
- (void)cellDidClickComment:(WeChatCell *)cell{
    
//    _commentIndex = maxCommentIndex;
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    self.commentIndexPath = indexPath;
    self.commentView.placeholder = @"评论";
    [self.commentView.textView becomeFirstResponder];
}

///***  发表评论 ***/
- (void)postCommentWithCommentText:(NSString *)text {
    
  
    WeChatModel *model = _layouts [_commentIndexPath.row];

    
    NSMutableArray* newCommentLists = [[NSMutableArray alloc] initWithArray:model.comments];
    
    NSDictionary* newComment = @{@"from":@"Nike",
                                 @"to":model.custName?model.custName:model.name,
                                 @"content":text?text:@"",
                                 };
    [newCommentLists insertObject:newComment atIndex:0];
    model.comments = newCommentLists;
    
    [_layouts replaceObjectAtIndex:_commentIndexPath.row withObject:model];
    
    [UIView animateWithDuration:0.0f animations:^{
        [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObjects:_commentIndexPath,nil] withRowAnimation:UITableViewRowAnimationNone];
    }];

}

//点击用户
- (void)cellDidClickUser:(WeChatCell *)cell{
//    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];

}

//查看更多
- (void)cellDidClickMoreComment:(WeChatCell *)cell{

}

//点赞评论用户名
- (void)cellDidClickLikeAndComment:(WeChatCell *)cell Name:(NSString *)name{
    NSLog(@"用户名：%@",name);
}

//视频播放
- (void)cellDidClickPlayVideo:(WeChatCell *)cell{

}

- (void)reloadData{

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSArray *dataArr = @[@{@"custName":@"小别离1",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确\n\n\n\n\n\n\n\n打开方式~",
                               @"pics":@[@"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jeloxwhnj30fu0g0ta5.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelpn9bdj30b40gkgmh.jpg",],
                               @"likes":@[@"linking",@"zhang",@"想",@"😔",@"zhang",@"想",@"zhang",@"想"],
                               @"time":@"2016/10/25",
                               @"comments":@[
                                       @{@"from":@"小别离",
                                         @"to":@"不点",
                                         @"content":@"你不要离开多岁的实打实的的圣诞树上大多数的三十多岁的的实打实的"
                                         },
                                       @{@"from":@"小别离",
                                         @"to":@"不点",
                                         @"content":@"这是真的吗？"
                                         },
                                       @{@"from":@"小别离",
                                         @"to":@"不点",
                                         @"content":@"今天我要去汉口，你要跟我一起去吗？😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊"
                                         },
                                       @{@"from":@"小别离",
                                         @"to":@"",
                                         @"content":@"你不要离开😐😣😡🚖"
                                         },
                                       @{@"from":@"小别离",
                                         @"to":@"不点",
                                         @"content":@"这是真的吗？"
                                         },
                                       @{@"from":@"小别离",
                                         @"to":@"不点",
                                         @"content":@"今天我要去汉口，你要跟我一起去吗？😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊"
                                         },]
                               },
                             @{@"custName":@"型格志style2",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确\n\n\n\n\n\n\n\n打开方式~",
                               @"pics":@[],
                               @"time":@"2016/10/25",
                               @"comments":@[
                                       @{@"from":@"小别离",
                                         @"to":@"不点",
                                         @"content":@"你不要离开多岁的实打实的的圣诞树上大多数的三十多岁的的实打实的"
                                         },
                                       @{@"from":@"小别离",
                                         @"to":@"不点",
                                         @"content":@"这是真的吗？"
                                         },
                                       @{@"from":@"小别离",
                                         @"to":@"不点",
                                         @"content":@"今天我要去汉口，你要跟我一起去吗？😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊😀😖😐😣😡🚖🚌🚋🎊"
                                         },
                                       @{@"from":@"小别离",
                                         @"to":@"",
                                         @"content":@"你不要离开😐😣😡🚖"
                                         }]
                                        },
                             @{@"custName":@"zhangxiang3",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确打开方式~😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确打开方式~😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确打开方式~😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确打开方式~",
                               @"pics":@[],
                               @"likes":@[@"linking",@"zhang",@"想",@"xiaohundan"],
                               @"time":@"2016/10/25",},
                             @{@"custName":@"小流xxxxx氓4",
                               @"name":@"大流氓",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"🎊春天卫衣的正确\n\n\n\n\n\n打开方式~，你知道吗",
                               @"pics":@[@"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jeloxwhnj30fu0g0ta5.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelpn9bdj30b40gkgmh.jpg",
                                         @"http://ww1.sinaimg.cn/mw690/006gWxKPgw1f2jelriw1bj30fz0g175g.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelt1kh5j30b10gmt9o.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jeluxjcrj30fw0fz0tx.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelzxngwj30b20godgn.jpg",
                                         @"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jelwmsoej30fx0fywfq.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jem32ccrj30xm0sdwjt.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jelyhutwj30fz0fxwfr.jpg",],
                               @"time":@"2016/10/25",
                               @"comments":@[
                                       @{@"from":@"你好",
                                         @"to":@"我好",
                                         @"content":@"大家好"
                                         },
                                       @{@"from":@"小的",
                                         @"to":@"",
                                         @"content":@"你的大法师的方式顶顶顶顶顶离开"
                                         }]},
                             @{@"custName":@"zhangxiang5",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确\n\n\n\n\n\n\n\n打开方式~",
                               @"pics":@[@"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jeloxwhnj30fu0g0ta5.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelpn9bdj30b40gkgmh.jpg",
                                         @"http://ww1.sinaimg.cn/mw690/006gWxKPgw1f2jelriw1bj30fz0g175g.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelt1kh5j30b10gmt9o.jpg",
                                         ],
                               @"likes":@[@"linking",@"昵称"],
                               @"time":@"2016/10/25"},
                             @{@"custName":@"zhangxiang6",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确\n\n\n\n\n\n\n\n打开方式~",
                               @"pics":@[@"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jeloxwhnj30fu0g0ta5.jpg",
                                         ],
                               @"time":@"2016/10/25"},
                             @{@"custName":@"zhangxiang7",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"ddddddddddddddddddddddddddd",
                               @"videoPic":@"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jeloxwhnj30fu0g0ta5.jpg",
                               @"pics":@[],
                               @"time":@"2016/10/25"},

                             @{@"custName":@"zhangxiang8",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确\n\n\n\n\n\n\n\n打开方式~",
                               @"pics":@[],
                               @"time":@"2016/10/25"},
                             @{@"custName":@"zhangxiang9",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确\n\n\n\n\n\n\n\n打开方式~",
                               @"pics":@[@"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jeloxwhnj30fu0g0ta5.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelpn9bdj30b40gkgmh.jpg",
                                         @"http://ww1.sinaimg.cn/mw690/006gWxKPgw1f2jelriw1bj30fz0g175g.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelt1kh5j30b10gmt9o.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jeluxjcrj30fw0fz0tx.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelzxngwj30b20godgn.jpg",
                                         @"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jelwmsoej30fx0fywfq.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jem32ccrj30xm0sdwjt.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jelyhutwj30fz0fxwfr.jpg",],
                               @"likes":@[@"linking"],
                               @"time":@"2016/10/25"},
                             @{@"custName":@"zhangxiang10",
                               @"name":@"型格志style",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确打开方式~😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确打开方式~😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确打开方式~😀😖😐😣😡🚖🚌🚋🎊春天卫衣的正确打开方式~",
                               @"pics":@[@"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jeloxwhnj30fu0g0ta5.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelpn9bdj30b40gkgmh.jpg",
                                         @"http://ww1.sinaimg.cn/mw690/006gWxKPgw1f2jelriw1bj30fz0g175g.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelt1kh5j30b10gmt9o.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jeluxjcrj30fw0fz0tx.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jelyhutwj30fz0fxwfr.jpg",],
                               @"time":@"2016/10/25"},
                             @{@"custName":@"小ss流氓11",
                               @"name":@"大流氓",
                               @"avatar":@"http://tp4.sinaimg.cn/5747171147/50/5741401933/0",
                               @"text":@"🎊春天卫衣的正确\n\n\n\n\n\n打开方式~，你知道吗",
                               @"pics":@[@"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jeloxwhnj30fu0g0ta5.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelpn9bdj30b40gkgmh.jpg",
                                         @"http://ww1.sinaimg.cn/mw690/006gWxKPgw1f2jelriw1bj30fz0g175g.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelt1kh5j30b10gmt9o.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jeluxjcrj30fw0fz0tx.jpg",
                                         @"http://ww3.sinaimg.cn/mw690/006gWxKPgw1f2jelzxngwj30b20godgn.jpg",
                                         @"http://ww2.sinaimg.cn/mw690/006gWxKPgw1f2jelwmsoej30fx0fywfq.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jem32ccrj30xm0sdwjt.jpg",
                                         @"http://ww4.sinaimg.cn/mw690/006gWxKPgw1f2jelyhutwj30fz0fxwfr.jpg",],
                               @"time":@"2016/10/25"},
                                        ];
        
        NSMutableArray *dataSource = [NSMutableArray array].mutableCopy;
      
        for (NSDictionary *dic in dataArr) {
            WeChatModel *model = [WeChatModel modelWithDictionary:dic];
            [dataSource addObject:model];
        }
        [_layouts addObjectsFromArray:dataSource];
        [_layouts addObjectsFromArray:dataSource];
        [_layouts addObjectsFromArray:dataSource];
        [_layouts addObjectsFromArray:dataSource];

        dispatch_async(dispatch_get_main_queue(), ^{
            self.navigationController.view.userInteractionEnabled = YES;
            [_tableView reloadData];
        });
    });

}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    if ([self.commentView.textView resignFirstResponder]) {
        [self.view endEditing:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

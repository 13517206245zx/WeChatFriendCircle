//
//  ViewController.h
//  ZXWeChat
//
//  Created by Mrs_zhang on 16/10/24.
//  Copyright © 2016年 Mrs_zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeChatViewController : UIViewController


@end

